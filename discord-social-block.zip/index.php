<?php
/**
 * Silence is golden.
 * @package DiscordSocialBlock
 */