wp.blocks.registerBlockVariation(
  'core/social-link',
  {
    name: 'discord',
    attributes: { service: 'discord', },
    title: 'Discord',
  },
)